# -*- coding: utf-8 -*-
from Components.Converter.Converter import Converter
from Components.Element import cached
from Poll import Poll
from Tools.HardwareInfo import HardwareInfo

class FlowCpuTemp(Poll, Converter, object):
	def __init__(self, type):
		Poll.__init__(self)
		Converter.__init__(self, type)
		self.type = type
		self.poll_enabled = True
		self.box = HardwareInfo().get_device_name()

	@cached
	def getText(self):
		if self.box == "dm900" or self.box == "dm920":
			f = open('/sys/class/thermal/thermal_zone0/temp', 'r')
			temp = f.read().strip()
			f.close()
			self.coretemp = format(float(temp) / 1000, '.1f')
			return str(self.coretemp)+'°C'

	text = property(getText)

	def changed(self, what):
		if what[0] == self.CHANGED_POLL:
			Converter.changed(self, what)
