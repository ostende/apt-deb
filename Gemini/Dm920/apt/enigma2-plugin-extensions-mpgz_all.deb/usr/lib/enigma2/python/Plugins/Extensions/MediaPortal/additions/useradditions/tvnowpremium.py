﻿# -*- coding: utf-8 -*-
from builtins import map
from Plugins.Extensions.MediaPortal.plugin import _
from Plugins.Extensions.MediaPortal.resources.imports import *
from Plugins.Extensions.MediaPortal.additions.mediatheken.tvnow import tvnowFirstScreen, tvnowSubGenreScreen, tvnowStaffelScreen, tvnowEpisodenScreen

default_cover = "file://%s/tvnowpremium.png" % (config_mp.mediaportal.iconcachepath.value + "logos")
name = "TVNOW PREMIUM"

class tvnowPremiumFirstScreen(tvnowFirstScreen):

	def __init__(self, session):
		tvnowFirstScreen.__init__(self, session, name=name, default_cover=default_cover)

	def genreData(self):
		self._items.append(("RTL", "rtl", default_cover))
		self._items.append(("VOX", "vox", default_cover))
		self._items.append(("RTL2", "rtl2", default_cover))
		self._items.append(("NITRO", "nitro",  default_cover))
		self._items.append(("SUPER RTL", "superrtl", default_cover))
		self._items.append(("RTLplus", "rtlplus",  default_cover))
		self._items.append(("RTLliving", "living",  default_cover))
		self.ml.setList(list(map(self._defaultlistcenter, self._items)))
		self.keyLocked = False
		self.showInfos()

	def keyOK(self):
		if self.keyLocked:
			return
		Name = self['liste'].getCurrent()[0][0]
		Link = self['liste'].getCurrent()[0][1]
		Image = self['liste'].getCurrent()[0][2]
		self.session.open(tvnowPremiumSubGenreScreen, Link, Name, Image)

class tvnowPremiumSubGenreScreen(tvnowSubGenreScreen):

	def __init__(self, session, Link, Name, Image):
		tvnowSubGenreScreen.__init__(self, session, Link, Name, Image, name=name, default_cover=default_cover)

	def parseData(self, data):
		nowdata = json.loads(data)
		for node in nowdata["items"]:
			image = str(node["defaultImage169Logo"])
			if image == "":
				image = str(node["defaultImage169Format"])
			if image == "":
				image = self.Image
			self._items.append((str(node["title"]), str(node["seoUrl"]), image))
		self._items.sort(key=lambda t : t[0].lower())
		self.ml.setList(list(map(self._defaultlistcenter, self._items)))
		self.keyLocked = False
		self.showInfos()

	def keyOK(self):
		exist = self['liste'].getCurrent()
		if self.keyLocked or exist == None:
			return
		Name = self.Name + ":" + self['liste'].getCurrent()[0][0]
		Link = self['liste'].getCurrent()[0][1]
		Image = self['liste'].getCurrent()[0][2]
		self.session.open(tvnowPremiumStaffelScreen, Link, Name, Image)

class tvnowPremiumStaffelScreen(tvnowStaffelScreen):

	def __init__(self, session, Link, Name, Image):
		tvnowStaffelScreen.__init__(self, session, Link, Name, Image, name=name, default_cover=default_cover)

	def keyOK(self):
		exist = self['liste'].getCurrent()
		if self.keyLocked or exist == None:
			return
		Name = self.Name + ":" + self['liste'].getCurrent()[0][0]
		Link = self['liste'].getCurrent()[0][1]
		if Link:
			self.session.open(tvnowPremiumEpisodenScreen, Link, Name, self.Image)

class tvnowPremiumEpisodenScreen(tvnowEpisodenScreen):

	def __init__(self, session, Link, Name, Image):
		tvnowEpisodenScreen.__init__(self, session, Link, Name, Image, name=name, default_cover=default_cover)

	def parseData(self, data):
		nowdata = json.loads(data)
		try:
			for node in nowdata["formatTabPages"]["items"]:
				try:
					try:
						containerid = str(node["container"]["id"])
						if containerid:
							self.container += 1
							self.loadContainer(containerid)
					except:
						for nodex in node["container"]["movies"]["items"]:
							try:
								if not nodex["isDrm"]:
									try:
										image = "http://ais.tvnow.de/rtlnow/%s/660x660/formatimage.jpg" % nodex["pictures"]["default"][0]["id"]
									except:
										image = self.Image
									if "broadcastStartDate" in nodex:
										date = str(nodex["broadcastStartDate"])
									else:
										date = ""
									if "episode" in nodex:
										episode = str(nodex["episode"])
									else:
										episode = ""
									descr = ""
									if date != "":
										date = re.findall('(\d{4})-(\d{2})-(\d{2}) (.*?)$', date)
										date = date[0][2] + "." + date[0][1] + "." + date[0][0] + ", " + date[0][3]
										descr = "Datum: " + date + "\n"
									if (episode != "None" and episode != ""):
										descr = descr + "Episode: " + episode + "\n"
									if descr != "":
										descr = descr + "\n"
									descrlong = str(nodex["articleLong"])
									if descrlong == "":
										descrshort = str(nodex["articleShort"])
									if descrlong != "":
										descr = descr + descrlong
									else:
										descr = descr + descrshort
									self._items.append((str(nodex["title"]), str(nodex["id"]), image, descr))
							except:
								continue
				except:
					continue
			self.parseContainer("", False)
		except:
			pass

	def parseContainer(self, data, id=False, annual=False):
		if id:
			self.container -= 1
			nowdata = json.loads(data)
			try:
				for nodex in nowdata["items"]:
					try:
						if not nodex["isDrm"]:
							try:
								image = "http://ais.tvnow.de/rtlnow/%s/660x660/formatimage.jpg" % nodex["pictures"]["default"][0]["id"]
							except:
								image = self.Image
							if "broadcastStartDate" in nodex:
								date = str(nodex["broadcastStartDate"])
							else:
								date = ""
							descr = ""
							if date != "":
								date = re.findall('(\d{4})-(\d{2})-(\d{2}) (.*?)$', date)
								date = date[0][2] + "." + date[0][1] + "." + date[0][0] + ", " + date[0][3]
								descr = "Datum: " + date + "\n"
							if "season" in nodex:
								season = str(nodex["season"])
							else:
								season = ""
							if "episode" in nodex:
								episode = str(nodex["episode"])
							else:
								episode = ""
							if (season != "None" and season != ""):
								descr = descr + "Staffel: " + season + "\n"
							if (episode != "None" and episode != ""):
								descr = descr + "Episode: " + episode + "\n"
							if descr != "":
								descr = descr + "\n"
							descrlong = str(nodex["articleLong"])
							if descrlong == "":
								descrshort = str(nodex["articleShort"])
							if descrlong != "":
								descr = descr + descrlong
							else:
								descr = descr + descrshort
							self._items.append((str(nodex["title"]), str(nodex["id"]), image, descr))
					except:
						continue
			except:
				pass
			if annual:
				self.parseContainer("", False)
		printl(self.container, self, "I")
		if self.container == 0:
			if len(self._items) == 0:
				self._items.append((_('Currently no playable episodes available!'), None, None, None))
			self._setList('_defaultlistleft', True)
			self.keyLocked = False
			self.showInfos()